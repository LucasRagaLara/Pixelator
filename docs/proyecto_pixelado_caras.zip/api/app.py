# === api/app.py ===
from flask import Flask, request, Response
import requests

app = Flask(__name__)

@app.route("/procesar", methods=["POST"])
def procesar():
    if "image" not in request.files:
        return "Falta el campo 'image'", 400

    file = request.files["image"]

    try:
        response = requests.post("http://engine:5000/handle", files={"image": file})
    except Exception as e:
        return f"Error al conectar con engine: {e}", 500

    return Response(response.content, content_type="image/jpeg")

app.run(host="0.0.0.0", port=8000)